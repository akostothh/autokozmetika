<form method="POST" action="productupdate.php">
    <table border="1">
        <thead>
            <tr>
                <th>id</th>
                <th>Név</th>
                <th>Ár</th>
                <th>Darabszám</th>
                <th>Leírás</th>
                <th>Új darabszám</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'kapcsolat.php';
            $sql = 'SELECT tid, nev, ar, darabszam, leiras FROM termekek';
            $termekek = mysqli_query($adb, $sql);

            while ($sor = mysqli_fetch_assoc($termekek)) {
                echo "<tr>";
                echo "<td>" . $sor['tid'] . "</td>";
                echo "<td>" . $sor['nev'] . "</td>";
                echo "<td>" . $sor['ar'] . "</td>";
                echo "<td>" . $sor['darabszam'] . "</td>";
                echo "<td>" . $sor['leiras'] . "</td>";
                echo "<td><input type='number' name='uj_darabszam[" . $sor['tid'] . "]' min='0'></td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    <button type="submit" name="frissit">Frissítés</button>
</form>
<style>
   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #f8f9fa, #d6e2f0);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}

table {
    width: 95%;
    max-width: 1100px;
    border-collapse: collapse;
    margin-top: 20px;
    border-radius: 15px;
    overflow: hidden;
    background: white;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 14px;
    text-align: center;
    border-bottom: 1px solid #ddd;
    font-size: 16px;
}

th {
    background: #0056b3;
    color: white;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
}

tr:nth-child(even) {
    background: #f1f3f5;
}

tr:hover {
    background: rgba(0, 123, 255, 0.1);
    transition: background 0.3s ease;
}

td {
    background: white;
    border-radius: 8px;
}

input[type="number"] {
    width: 80px;
    padding: 8px;
    border: 2px solid #007bff;
    border-radius: 8px;
    font-size: 14px;
    text-align: center;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="number"]:focus {
    border-color: #0056b3;
    box-shadow: 0 0 8px rgba(0, 86, 179, 0.3);
}

button {
    padding: 12px 18px;
    border: none;
    background: #28a745;
    color: white;
    font-weight: bold;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s ease;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    font-size: 16px;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 15px;
}

button:hover {
    background: #218838;
    transform: translateY(-2px);
}

button:active {
    transform: scale(0.95);
}

    </style>