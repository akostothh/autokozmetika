<?php
include 'kapcsolat.php';

if (isset($_POST['delete_users']) && !empty($_POST['uid'])) {
    $uids = $_POST['uid']; // A kijelölt felhasználók ID-jai

    // SQL lekérdezés előkészítése a törléshez
    $sql = "DELETE FROM user WHERE uid = ?";
    $stmt = mysqli_prepare($adb, $sql);

    // Törlés minden kijelölt felhasználóra
    foreach ($uids as $uid) {
        mysqli_stmt_bind_param($stmt, 'i', $uid);
        mysqli_stmt_execute($stmt);
    }

    echo "A kijelölt felhasználók sikeresen törölve!";
    mysqli_stmt_close($stmt);
} else {
    echo "Nincs kijelölt felhasználó a törléshez!";
}

mysqli_close($adb);
header("Location: index.php"); // Visszairányítás
exit();
?>