<?php
// Adatbázis kapcsolat létrehozása
include 'kapcsolat.php';

// Ellenőrizzük, hogy a POST kérésben van-e 'vid' paraméter
if (isset($_POST['vid'])) {
    // A 'vid' paraméter értékének elmentése
    $id = $_POST['vid'];

    // SQL lekérdezés előkészítése a vélemény törléséhez
    $sql = "DELETE FROM velemeny WHERE vid = ?";
    
    // Prepared statement létrehozása
    $stmt = mysqli_prepare($adb, $sql);
    
    // Paraméter bindolása
    mysqli_stmt_bind_param($stmt, 'i', $id);
    
    // SQL lekérdezés végrehajtása
    if (mysqli_stmt_execute($stmt)) {
        echo "A vélemény sikeresen törölve!";
    } else {
        echo "Hiba történt a törlés során: " . mysqli_error($adb);
    }
    
    // Statement lezárása
    mysqli_stmt_close($stmt);
} else {
    echo "Nincs megadva törlendő vélemény!";
}

// Adatbázis kapcsolat lezárása
mysqli_close($adb);

// Visszairányítás az előző oldalra
header("Location: index.php");
exit();
?>