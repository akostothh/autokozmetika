<?php
include 'kapcsolat.php';

if (isset($_POST['frissit']) && isset($_POST['uj_darabszam'])) {
    $uj_darabszamok = $_POST['uj_darabszam']; // Az összes termék új darabszáma

    // SQL lekérdezés előkészítése a frissítéshez
    $sql = "UPDATE termekek SET darabszam = ? WHERE tid = ?";
    $stmt = mysqli_prepare($adb, $sql);

    // Tömb bejárása és minden termék frissítése
    foreach ($uj_darabszamok as $tid => $uj_darabszam) {
        // Ellenőrizzük, hogy az új darabszám érvényes szám-e
        if (is_numeric($uj_darabszam) && $uj_darabszam >= 0) {
            // Paraméterek bindolása
            mysqli_stmt_bind_param($stmt, 'ii', $uj_darabszam, $tid);

            // SQL lekérdezés végrehajtása
            if (!mysqli_stmt_execute($stmt)) {
                echo "Hiba történt a termék (ID: $tid) frissítése során: " . mysqli_error($adb) . "<br>";
            }
        } else {
            echo "Érvénytelen darabszám a termékhez (ID: $tid)!<br>";
        }
    }

    echo "A termékek darabszáma sikeresen frissítve!";
    mysqli_stmt_close($stmt);
} else {
    echo "Nincs kiválasztott termék vagy darabszám!";
}

mysqli_close($adb);
header("Location: index.php"); // Visszairányítás
exit();
?>