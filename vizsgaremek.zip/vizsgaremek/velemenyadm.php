<table border="1">
    <thead>
        <tr>
            <th>id</th>
            <th>Felhasználó</th>
            <th>Vélemény</th>
            <th>Értékelés</th>
            <th>Dátum</th>
            <th>Törlés</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include 'kapcsolat.php';
        $sql = 'SELECT v.vid, u.unick, v.comment, v.rate, v.date 
                FROM velemeny v 
                LEFT JOIN user u ON v.uid = u.uid';
        $velemenyek = mysqli_query($adb, $sql);

        while ($sor = mysqli_fetch_assoc($velemenyek)) {
            echo "<tr>";
            echo "<td>" . $sor['vid'] . "</td>";
            echo "<td>" . $sor['unick'] . "</td>";
            echo "<td>" . $sor['comment'] . "</td>";
            echo "<td>" . $sor['rate'] . "</td>";
            echo "<td>" . $sor['date'] . "</td>";
            echo "<td> 
                    <form method='POST' action='ratedelete.php'> 
                        <input type='hidden' name='vid' value='". $sor['vid'] . "'>
                        <button type='submit'>Törlés</button> 
                    </form> 
                  </td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #eef2f3, #d9e6f2);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}

table {
    width: 90%;
    max-width: 1000px;
    border-collapse: collapse;
    margin-top: 20px;
    border-radius: 15px;
    overflow: hidden;
    background: white;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 14px;
    text-align: center;
    border-bottom: 1px solid #ddd;
    font-size: 16px;
}

th {
    background: #0056b3;
    color: white;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
}

tr:nth-child(even) {
    background: #f1f3f5;
}

tr:hover {
    background: rgba(0, 123, 255, 0.1);
    transition: background 0.3s ease;
}

td {
    background: white;
    border-radius: 8px;
}

input[type="checkbox"] {
    transform: scale(1.3);
    cursor: pointer;
    accent-color: #007bff;
}

button {
    padding: 12px 18px;
    border: none;
    background: #dc3545;
    color: white;
    font-weight: bold;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s ease;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    font-size: 16px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

button:hover {
    background: #c82333;
    transform: translateY(-2px);
}

button:active {
    transform: scale(0.95);
}

td:last-child {
    display: flex;
    justify-content: center;
    align-items: center;
}

</style>