<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/fevicon.png" type="image/x-icon">
  <title>Finter</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->


  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">
  <div class="hero_area">
    <div class="hero_bg_box">
      <img src="images/hero-bg.jpg" alt="">
    </div>

  </div>

  <!-- team section -->

  <section class="team_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2 class="text-light">
          A mi csapatunk
        </h2>
        <p>
        Csapatunk szenvedéllyel és szakértelemmel gondoskodik autódról, hogy mindig a legjobb formáját hozza. Tapasztalt autókozmetikai szakembereink precíz munkát végeznek, legyen szó külső-belső tisztításról, bevonatokról vagy prémium ápolásról. Nálunk az ügyfél elégedettsége az első, ezért minőségi anyagokkal és modern technológiákkal dolgozunk. Bízd ránk autódat, és garantáljuk, hogy ragyogóan tisztán kapod vissza!
        </p>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-6 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="kepek/munkas1.webp" alt="">
            </div>
            <div class="detail-box">
              <h5>
              Rácz Péter (Petyus)
              </h5>
              <h6 class="">
              autókozmetikai szakértő

              </h6>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="kepek/munkas.webp" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Denny Butler
              </h5>
              <h6 class="">
                supervisor
              </h6>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="kepek/munkas2.webp" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Nathan Mcpherson
              </h5>
              <h6 class="">
                supervisor
              </h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end team section -->

  <!-- info section -->
 

  <!-- end info_section -->

  <!-- footer section -->
  
</body>

</html>
<style>
   body{
  background-color:black;
  }
  </style>