<br>
    <br>
    <br>
    <br>
    
<div class="admin-menu">
    <a href="useradm.php">Felhasználók</a>
    <a href="velemenyadm.php">Vélemények</a>
    <a href="productadm.php">Termékek</a>
 

</div>
<br>
    <br>
    <br>
    <br>
    
<style>
    .admin-menu {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 20px;
    }

    a {
        display: inline-block;
        padding: 12px 20px;
        text-decoration: none;
        font-weight: bold;
        border-radius: 8px;
        transition: background 0.3s ease, transform 0.2s ease;
        text-align: center;
        min-width: 120px;
    }

    a[href="velemenyadm.php"] {
        background: #007bff;
        color: white;
    }

    a[href="useradm.php"], 
    a[href="productadm.php"] {
        background: #28a745;
        color: white;
    }

    a:hover {
        opacity: 0.85;
        transform: translateY(-2px);
    }

    a:active {
        transform: translateY(1px);
    }
</style>
